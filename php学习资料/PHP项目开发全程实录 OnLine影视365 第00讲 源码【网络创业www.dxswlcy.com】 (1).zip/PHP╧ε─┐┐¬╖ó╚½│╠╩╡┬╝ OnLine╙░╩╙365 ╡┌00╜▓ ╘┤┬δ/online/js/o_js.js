// JavaScript Document
//����Ϣ�¼�
function type(e_type)
{
  	var win=window.open("Operation.php?action=" + e_type +  ","","height=400,width=500,scrollbars=no");
}