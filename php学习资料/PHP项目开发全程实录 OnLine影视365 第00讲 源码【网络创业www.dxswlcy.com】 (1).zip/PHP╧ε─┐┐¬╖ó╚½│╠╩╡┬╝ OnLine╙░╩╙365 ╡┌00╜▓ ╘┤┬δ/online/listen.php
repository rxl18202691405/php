<?php
	session_start();
	
?>
<body leftmargin="0" topmargin="0"> 
	<center>
	<embed src="upfiles/video/<?php echo $_GET[id];?>" ShowStatusBar=true></embed>
	</center>
</body>
