<?php
	session_start();
	session_destroy();
?>
<script language="javascript">
	alert("�Ѿ���ȫ�˳�!");
	location="index.php";
</script>