<?php
	$types=$_POST[style];
	$days=$_POST[days];
?>


<script language="javascript">
	top.opener.location="main.php?action=log&types=<?php echo $types; ?>&days=<?php echo $days; ?>";
	top.window.close();
</script>
